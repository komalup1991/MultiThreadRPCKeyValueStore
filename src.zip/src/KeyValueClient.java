import java.rmi.Naming;

public class KeyValueClient {

    public static void main(String[] args) {
        // Set timeout values for RMI connections and responses
        System.setProperty("sun.rmi.transport.connectionTimeout", "5000"); // 5 sec for connection
        System.setProperty("sun.rmi.transport.tcp.responseTimeout", "5000"); // 5 sec for response
        try {
            KeyValueInterface server = (KeyValueInterface) Naming.lookup("rmi://localhost/KeyValueService");
            ClientUtil.log("Connected to Key-Value Server.");

            // Check if prepopulation is needed
            if (!server.checkPrepopulated()) {
                String[] prepopulateCommands = {
                        "PUT name Jasmine",
                        "PUT age 28",
                        "PUT city San Jose",
                        "PUT country USA",
                        "PUT language English"
                };

                for (String command : prepopulateCommands) {
                    String response = sendRequest(server, command);
                    ClientUtil.log("Prepopulated: " + command + " -> " + response);
                }

                // Mark prepopulation as complete
                server.setPrepopulated();
                ClientUtil.log("Prepopulation complete.");
            } else {
                ClientUtil.log("Server is already prepopulated.");
            }

            while (true) {
                String command = ClientUtil.getUserInput();
                if (command.equalsIgnoreCase("exit")) {
                    ClientUtil.log("Exiting client...");
                    break;
                }

                if (!ClientUtil.isValidCommand(command)) {
                    ClientUtil.log("Invalid command. Use: PUT <key> <value>, GET <key>, DELETE <key>");
                    continue;
                }

                String response = sendRequest(server, command);
                ClientUtil.log("Server Response: " + response);
            }
        } catch (Exception e) {
            ClientUtil.log("Client Error: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private static String sendRequest(KeyValueInterface server, String command) throws Exception {
        Command c = CommandUtil.createCommand(command);
        return switch (c.getOperation()) {
            case "PUT" -> server.put(c.getKey(), c.getValue());
            case "GET" -> server.get(c.getKey());
            case "DELETE" -> server.delete(c.getKey());
            default -> "Error: Unknown command";
        };
    }
}