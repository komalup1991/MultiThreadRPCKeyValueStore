import java.text.SimpleDateFormat;
import java.util.Date;

public class ServerUtil {
    // Date formatter for logging timestamps
    private static final SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");

    /**
     * Logs a message with a timestamp.
     * 
     * @param message The message to log.
     */
    public static void log(String message) {
        System.out.println(dateFormat.format(new Date()) + " - " + message);
    }
}