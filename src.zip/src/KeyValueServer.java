import java.rmi.Naming;
import java.rmi.registry.LocateRegistry;

public class KeyValueServer {
    public static void main(String[] args) {
        try {
            LocateRegistry.createRegistry(1099); // Start RMI registry
            KeyValueInterface server = new KeyValueImpl();
            Naming.rebind("KeyValueService", server);
            ServerUtil.log("Key-Value Server is running...");
        } catch (Exception e) {
            ServerUtil.log("Server Error: " + e.getMessage());
            e.printStackTrace();
        }
    }
}