import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.concurrent.ConcurrentHashMap;

public class KeyValueImpl extends UnicastRemoteObject implements KeyValueInterface {
    private static final long serialVersionUID = 1L;
    private static ConcurrentHashMap<String, String> store = new ConcurrentHashMap<>();
    private boolean isPrepopulated = false; // Ensures data is loaded only once

    protected KeyValueImpl() throws java.rmi.RemoteException {
        super();
    }

    @Override
    public String put(String key, String value) throws RemoteException {
        store.put(key, value);
        logClientRequest("PUT " + key + " " + value);
        return "Success: Key " + key + " stored.";
    }

    @Override
    public String get(String key) throws RemoteException {
        String value = store.get(key);
        logClientRequest("GET " + key);
        return (value != null) ? value : "Error: Key not found.";
    }

    @Override
    public String delete(String key) throws RemoteException {
        String removed = store.remove(key);
        logClientRequest("DELETE " + key);
        return (removed != null) ? "Success: Key " + key + " deleted." : "Error: Key not found.";
    }

    @Override
    public boolean checkPrepopulated() throws RemoteException {
        return isPrepopulated;
    }

    @Override
    public synchronized void setPrepopulated() throws RemoteException {
        isPrepopulated = true;
    }

    /**
     * Logs client requests, including which thread is handling them.
     */
    private void logClientRequest(String request) {
        try {
            String clientHost = java.rmi.server.RemoteServer.getClientHost();
            String threadName = Thread.currentThread().getName();
            ServerUtil.log("[" + threadName + "] Client [" + clientHost + "] sent: " + request);
        } catch (Exception e) {
            ServerUtil.log("Error getting client host: " + e.getMessage());
        }
    }
}